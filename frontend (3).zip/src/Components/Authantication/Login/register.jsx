// import React, { useState } from 'react';
// import { useNavigate } from 'react-router-dom';
// const Register = () => {
//     const [user, setUser] = useState({
//         username: '',
//         email: '',
//         phone: '',
//         address:'',
//         password: '',
//         role:'user',
//         storeName:" "
//       });
    
//       const [userType,setUserType] = useState();
    
//       const handleChange = (e) => {
//         const { name, value } = e.target;
//         setUser(prevUser => ({
//             ...prevUser,
//             [name]: value,
//         }));
//     };
//     const navigate = useNavigate();
//       const handleSubmit = async (e) => {
//         e.preventDefault();
//         if (userType === "retailer") {
//           user.role = "retailer";
//         }

//         if(user.username)
//         try {
//           const response = await fetch(`http://localhost:3000/api/auth/signup`,{
//             method: "POST",
//             headers:{
//               "Content-Type": "application/json",
//             },
//             body: JSON.stringify(user),
//           });
//             console.log("User registered:", response)
//             if(response.ok)
//             {
//               alert('Register Successfully Done!')
//               setUser({
//                 username: '',
//                 email: '',
//                 phone: '',
//                 address:'',
//                 password: '',
//                 storeName:''
//               })
//               navigate("/login")
//             }
//             else
//             {
//               alert("Connection failed")
//             }
    
//         } catch (error) {
//           console.log(error)
//         }
//         // Add your registration logic here (e.g., API call, etc.)
//         // console.log('Register Form submitted:', user);
//       };
    


//   return (

//     <div className="hero min-h-screen bg-base-200 flex justify-center items-center">
//       <div className="hero-content flex flex-col  lg:flex-row justify-center items-center " style={{gap:"6rem", paddingTop:"13vh" }}>
//         {/* Image on the left side */}
//         <div className="hidden lg:block lg:w-1/2">
//           <img src="loginAnimation.gif" alt="Your Image" className="h-auto" style={{width:"38rem", borderRadius:"80%"}} />
//         </div>
//         {/* Login form on the right side */}
//        <div className='w-full lg:w-1/2 sm:w-100'>
//         <div className="card w-full  shadow-2xl bg-base-100 " >
//           <form className="card-body border-none" >
//             {/* roleee */}

//            <div className='role'>
//            <div className="form-check form-check-inline fs-6">
//             <label className="form-check-label fs-5 fw-bold" htmlFor="inlineRadio1">Register As</label>
//           </div>
//           <div className="form-check form-check-inline fs-6">
//             <input className="form-check-input" type="radio" name="userType" id="user" value="user" onChange={(e) => setUserType(e.target.value)} />
//             <label className="form-check-label fs-6" htmlFor="user">User</label>
//           </div>
//           <div className="form-check form-check-inline fs-6">
//             <input className="form-check-input" type="radio" name="userType" id="retailer" value="retailer" onChange={(e) => setUserType(e.target.value)} />
//             <label className="form-check-label fs-6" htmlFor="retailer">Retailer</label>
//           </div>
//           <div className="form-check form-check-inline fs-6">
//             <input className="form-check-input" type="radio" name="userType" id="admin" value="admin" onChange={(e) => setUserType(e.target.value)} />
//             <label className="form-check-label fs-6" htmlFor="Admin">Admin</label>
//           </div>
//            </div>
//            {userType === "retailer" ? 
//         <>  
//           <h1>Store Name</h1>
//             <input
//               type="text"
//               placeholder="Enter a Store Name"
//               name="storeName"
//               value={user.storeName}
//               onChange={handleChange}
//             />
//           </> : null}

//             <div className="text-center lg:text-left">
//               <h1 className=" font-bold  text-center " style={{fontSize:"1.4rem"}}>Register now</h1>
//             </div>
//             <div className="form-control p-0 border-none">
//               <label className="label">
//                 <span className="label-text">UserName</span>
//               </label>
//               <input type="text" placeholder="Enter a username" className="input input-bordered" 
//                name="username"
//              value={user.username} 
//              onChange={handleChange}
//              required
//            />
//             </div>
//             <div className="form-control p-0 border-none">
//               <label className="label">
//                 <span className="label-text">Email</span>
//               </label>
//               <input type="email" placeholder="email" className="input input-bordered"  name="email"
//              value={user.email} 
//              onChange={handleChange} required />
//             </div>

//             {/* Phone  */}
//             <div className="form-control p-0 border-none">
//               <label className="label">
//                 <span className="label-text">Phone</span>
//               </label>
//               <input type="text" placeholder="Phone" className="input input-bordered"  name="phone"
//              value={user.phone} 
//              onChange={handleChange} required />
//             </div>
//             <div className="form-control p-0 border-none">
//               <label className="label">
//                 <span className="label-text">Address</span>
//               </label>
//               <input type="text" placeholder="Address" className="input input-bordered"  
//                name="address"
//              value={user.address} 
//              onChange={handleChange} required />
//             </div>
//             <div className="form-control p-0 border-none">
//               <label className="label">
//                 <span className="label-text">Password</span>
//               </label>
//               <input 
//               type="password" 
//               placeholder="password" 
//               className="input input-bordered"  
//                name="password"
//              value={user.password} 
//              onChange={handleChange} 
//              required 
//              />
        
//             </div>
//             <div className="form-control mt-4">
//               <button className="btn btn-primary text-white font-bold border-none outline-none" onClick={handleSubmit}>Register</button>
//             </div>
//           </form>
//         </div>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default Register;

// 1st

// import React, { useState } from 'react';
// import { useNavigate } from 'react-router-dom';

// const Register = () => {
//     const [user, setUser] = useState({
//         username: '',
//         email: '',
//         phone: '',
//         address:'',
//         password: '',
//         role:'',
//         storeName:""
//     });
    
//     const [role, setRole] = useState();
//     const navigate = useNavigate();

//     const handleChange = (e) => {
//         const { name, value } = e.target;
//         setUser(prevUser => ({
//             ...prevUser,
//             [name]: value,
//         }));
//     };

//     const handleSubmit = async (e) => {
//         e.preventDefault();
//         console.log(role=="retailer")
//         if (role == "retailer") {
//             setUser.role = "retailer";
//             console.log(user.role)
//             try {
//                 const response = await fetch(`http://localhost:3000/api/auth/signup`,{
//                     method: "POST",
//                     headers:{
//                         "Content-Type": "application/json",
//                     },
//                     body: JSON.stringify(user),
//                 });
//                 // console.log("User registered:", response)
//                 if(response.ok)
//                 {
//                     alert('Register Successfully Done!')
//                     setUser({
//                         username: '',
//                         email: '',
//                         phone: '',
//                         address:'',
//                         password: '',
//                         storeName:'',
//                         role:'retailer'
//                     })
//                     navigate("/login")
//                 }
//                 else
//                 {
//                     alert("Connection failed")
//                 }
    
//             } catch (error) {
//                 console.log(error)
//             }
//         }
//         else{
//             setUser.role = "retailer";
//             console.log(user.role)
//             try {
//                 const response = await fetch(`http://localhost:3000/api/auth/signup`,{
//                     method: "POST",
//                     headers:{
//                         "Content-Type": "application/json",
//                     },
//                     body: JSON.stringify(user),
//                 });
//                 // console.log("User registered:", response)
//                 if(response.ok)
//                 {
//                     alert('Register Successfully Done!')
//                     setUser({
//                         username: '',
//                         email: '',
//                         phone: '',
//                         address:'',
//                         password: '',
//                         storeName:'',
//                         role:'user'
//                     })
//                     navigate("/login")
//                 }
//                 else
//                 {
//                     alert("Connection failed")
//                 }
    
//             } catch (error) {
//                 console.log(error)
//             }
//         }
      
//     };

//     return (
//         <div className="hero min-h-screen bg-base-200 flex justify-center items-center">
//             <div className="hero-content flex flex-col  lg:flex-row justify-center items-center " style={{gap:"6rem", paddingTop:"13vh" }}>
//                 {/* Image on the left side */}
//                 <div className="hidden lg:block lg:w-1/2">
//                     <img src="loginAnimation.gif" alt="Your Image" className="h-auto" style={{width:"38rem", borderRadius:"80%"}} />
//                 </div>
//                 {/* Login form on the right side */}
//                 <div className='w-full lg:w-1/2 sm:w-100'>
//                     <div className="card w-full  shadow-2xl bg-base-100 " >
//                         <form className="card-body border-none" >
//                             {/* roleee */}
//                             <div className='flex gap-4"'>
//                                 <div className="form-check form-check-inline fs-6">
//                                     <label className="form-check-label fs-5 fw-bold font-bold" htmlFor="inlineRadio1">Register As</label>
//                                 </div>
//                                 <div className="form-check form-check-inline fs-6">
//                                     <input className="form-check-input" type="radio" name="role" id="user" value="user" onChange={(e) => setRole(e.target.value)} />
//                                     <label className="form-check-label fs-6" htmlFor="user">User</label>
//                                 </div>
//                                 <div className="form-check form-check-inline fs-6">
//                                     <input className="form-check-input" type="radio" name="role" id="retailer"
//                                      value="retailer" onChange={(e) => setRole(e.target.value)} />
//                                     <label className="form-check-label fs-6" htmlFor="retailer">Retailer</label>
//                                 </div>
                               
//                             </div>
//                             {/* Conditional rendering of Store Name input */}
                         
//                             <div className="text-center lg:text-left">
//                                 <h1 className=" font-bold  text-center " style={{fontSize:"1.4rem"}}>Register now</h1>
//                             </div>

//                             {/* for retailer to sstore  */}
//                             {role == "retailer" && (
//                                 <div className="form-control p-0 border-none">
//                                     <label className="label">
//                                         <span className="label-text">Store Name</span>
//                                     </label>
//                                     <input
//                                         type="text"
//                                         placeholder="Enter a Store Name"
//                                         className="input input-bordered"
//                                         name="storeName"
//                                         value={user.storeName}
//                                         onChange={handleChange}
//                                     />
//                                 </div>
//                             )}
//                             {/* Username */}
//                             <div className="form-control p-0 border-none">
//                                 <label className="label">
//                                     <span className="label-text">Username</span>
//                                 </label>
//                                 <input
//                                     type="text"
//                                     placeholder="Enter a username"
//                                     className="input input-bordered"
//                                     name="username"
//                                     value={user.username}
//                                     onChange={handleChange}
//                                     required
//                                 />
//                             </div>
//                             {/* Email */}
//                             <div className="form-control p-0 border-none">
//                                 <label className="label">
//                                     <span className="label-text">Email</span>
//                                 </label>
//                                 <input
//                                     type="email"
//                                     placeholder="Email"
//                                     className="input input-bordered"
//                                     name="email"
//                                     value={user.email}
//                                     onChange={handleChange}
//                                     required
//                                 />
//                             </div>
//                             {/* Phone */}
//                             <div className="form-control p-0 border-none">
//                                 <label className="label">
//                                     <span className="label-text">Phone</span>
//                                 </label>
//                                 <input
//                                     type="text"
//                                     placeholder="Phone"
//                                     className="input input-bordered"
//                                     name="phone"
//                                     value={user.phone}
//                                     onChange={handleChange}
//                                     required
//                                 />
//                             </div>
//                             {/* Address */}
//                             <div className="form-control p-0 border-none">
//                                 <label className="label">
//                                     <span className="label-text">Address</span>
//                                 </label>
//                                 <input
//                                     type="text"
//                                     placeholder="Address"
//                                     className="input input-bordered"
//                                     name="address"
//                                     value={user.address}
//                                     onChange={handleChange}
//                                     required
//                                 />
//                             </div>
//                             {/* Password */}
//                             <div className="form-control p-0 border-none">
//                                 <label className="label">
//                                     <span className="label-text">Password</span>
//                                 </label>
//                                 <input
//                                     type="password"
//                                     placeholder="Password"
//                                     className="input input-bordered"
//                                     name="password"
//                                     value={user.password}
//                                     onChange={handleChange}
//                                     required
//                                 />
//                             </div>
//                             {/* Register Button */}
//                             <div className="form-control mt-4">
//                                 <button className="btn btn-primary text-white font-bold border-none outline-none" onClick={handleSubmit}>Register</button>
//                             </div>
//                         </form>
//                     </div>
//                 </div>
//             </div>
//         </div>
//     );
// };

// export default Register;

// chat 


import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const Register = () => {
    const [user, setUser] = useState({
        username: '',
        email: '',
        phone: '',
        address:'',
        password: '',
        role:'',
        storeName:""
    });
    
    const [role, setRole] = useState('');
    const navigate = useNavigate();

    const handleChange = (e) => {
        const { name, value } = e.target;
        setUser(prevUser => ({
            ...prevUser,
            [name]: value,
        }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        try {
            const userData = {
                ...user,
                role: role === 'retailer' ? 'retailer' : 'user'
            };

            const response = await fetch(`http://localhost:3000/api/auth/signup`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify(userData),
            });

            if (response.ok) {
                alert('Registration successful!');
                setUser({
                    username: '',
                    email: '',
                    phone: '',
                    address: '',
                    password: '',
                    storeName: '',
                    role: ''
                });
                navigate("/login");
            } else {
                alert("Registration failed. Please try again.");
            }
        } catch (error) {
            console.log(error);
            alert("An error occurred. Please try again later.");
        }
    };

    return (
        <div className="hero min-h-screen bg-base-200 flex justify-center items-center">
            <div className="hero-content flex flex-col  lg:flex-row justify-center items-center " style={{gap:"6rem", paddingTop:"13vh" }}>
                {/* Image on the left side */}
                <div className="hidden lg:block lg:w-1/2">
                    <img src="loginAnimation.gif" alt="Your Image" className="h-auto" style={{width:"38rem", borderRadius:"80%"}} />
                </div>
                {/* Login form on the right side */}
                <div className='w-full lg:w-1/2 sm:w-100'>
                    <div className="card w-full  shadow-2xl bg-base-100 " >
                        <form className="card-body border-none" >
                            {/* role */}
                            <div className='flex gap-4"'>
                                <div className="form-check form-check-inline fs-6">
                                    <label className="form-check-label fs-5 fw-bold font-bold" htmlFor="inlineRadio1">Register As</label>
                                </div>
                                <div className="form-check form-check-inline fs-6">
                                    <input className="form-check-input" type="radio" name="role" id="user" value="user" onChange={(e) => setRole(e.target.value)} />
                                    <label className="form-check-label fs-6" htmlFor="user">User</label>
                                </div>
                                <div className="form-check form-check-inline fs-6">
                                    <input className="form-check-input" type="radio" name="role" id="retailer"
                                     value="retailer" onChange={(e) => setRole(e.target.value)} />
                                    <label className="form-check-label fs-6" htmlFor="retailer">Retailer</label>
                                </div>
                            </div>
                            {/* Conditional rendering of Store Name input */}
                            {role === "retailer" && (
                                <div className="form-control p-0 border-none">
                                    <label className="label">
                                        <span className="label-text">Store Name</span>
                                    </label>
                                    <input
                                        type="text"
                                        placeholder="Enter a Store Name"
                                        className="input input-bordered"
                                        name="storeName"
                                        value={user.storeName}
                                        onChange={handleChange}
                                    />
                                </div>
                            )}
                            {/* Username */}
                            <div className="form-control p-0 border-none">
                                <label className="label">
                                    <span className="label-text">Username</span>
                                </label>
                                <input
                                    type="text"
                                    placeholder="Enter a username"
                                    className="input input-bordered"
                                    name="username"
                                    value={user.username}
                                    onChange={handleChange}
                                    required
                                />
                            </div>
                            {/* Email */}
                            <div className="form-control p-0 border-none">
                                <label className="label">
                                    <span className="label-text">Email</span>
                                </label>
                                <input
                                    type="email"
                                    placeholder="Email"
                                    className="input input-bordered"
                                    name="email"
                                    value={user.email}
                                    onChange={handleChange}
                                    required
                                />
                            </div>
                            {/* Phone */}
                            <div className="form-control p-0 border-none">
                                <label className="label">
                                    <span className="label-text">Phone</span>
                                </label>
                                <input
                                    type="text"
                                    placeholder="Phone"
                                    className="input input-bordered"
                                    name="phone"
                                    value={user.phone}
                                    onChange={handleChange}
                                    required
                                />
                            </div>
                            {/* Address */}
                            <div className="form-control p-0 border-none">
                                <label className="label">
                                    <span className="label-text">Address</span>
                                </label>
                                <input
                                    type="text"
                                    placeholder="Address"
                                    className="input input-bordered"
                                    name="address"
                                    value={user.address}
                                    onChange={handleChange}
                                    required
                                />
                            </div>
                            {/* Password */}
                            <div className="form-control p-0 border-none">
                                <label className="label">
                                    <span className="label-text">Password</span>
                                </label>
                                <input
                                    type="password"
                                    placeholder="Password"
                                    className="input input-bordered"
                                    name="password"
                                    value={user.password}
                                    onChange={handleChange}
                                    required
                                />
                            </div>
                            {/* Register Button */}
                            <div className="form-control mt-4">
                                <button className="btn btn-primary text-white font-bold border-none outline-none" onClick={handleSubmit}>Register</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Register;
