// // chat
// import React from "react";
// import axios from "axios";
// import { useParams } from "react-router-dom";
// import { HiOutlineArrowCircleRight } from "react-icons/hi";
// import { useContext ,useState, useEffect } from 'react';
// import { groceryContext } from '../../Layout/Layout';
// import { handleSessionStorage } from '../../../utils/utils';


// const SingleProduct = () => {

//   const params = useParams();
//   const [product, setProduct] = useState(null);

//   useEffect(() => {
//     if (params?.slug) {
//       getProduct(params.slug);
//     }
//   }, [params?.slug]);

//   const getProduct = async () => {
//     try {
//       const { data } = await axios.get(
//         `http://localhost:3000/api/vi/product/get-product/${params.slug}`
//       );
//       setProduct(data?.product);
//       console.log(data.product._id);
//     } catch (error) {}
//   };

  
//   const [openAlert, setOpenAlert] = useState(false)
//   const { cartItemsState } = useContext(groceryContext);
//   const [cartItems, setCartItems] = cartItemsState;

//   //Handle Add To Cart
//   const handleAddToCartBtn = () => {
//       let targetedProduct = product;
//       let latestCartItems = cartItems;

//       const isTargetedProductAlreadyExist = cartItems.find(item => item.id === product.id)
//       if (isTargetedProductAlreadyExist) {
//           targetedProduct = {
//               ...isTargetedProductAlreadyExist,
//               quantity: isTargetedProductAlreadyExist.quantity + 1,
//               total: ((isTargetedProductAlreadyExist.quantity + 1) * isTargetedProductAlreadyExist.price).toFixed(2)
//           }
//           latestCartItems = cartItems.filter(item => item.id !== targetedProduct.id)
//       }
//       setCartItems([
//           targetedProduct,
//           ...latestCartItems
//       ])
//       handleSessionStorage('set', 'cartItems', [
//           targetedProduct,
//           ...latestCartItems
//       ])

//       setOpenAlert(!openAlert)
//   }
//   return (
//     <div>
//       {product && (
//         <div className="p-3 max-w-7xl m-auto">
//           <div className="mt-6 sm:mt-10 p-12">
//             <div>
//               <h1 className="text-2xl font-medium font-poppins">
//                 Product Details
//               </h1>
//               <div className="grid gird-cols-1 md:grid-cols-3 sm:grid-cols-2 gap-6 h-max">
//                 {/* Product Image */}
//                 <div className="overflow-hidden rounded-xl">
//                   <img
//                     src={`http://localhost:3000/api/vi/product/product-photo/${product._id}`}
//                     //   alt={product.name}
//                     className="w-full"
//                   />
//                 </div>
//                 {/* Product Details */}
//                 <div className="flex flex-col justify-between">
//                   <div>
//                     {/* Product Title */}
//                     <h1 className="text-3xl text-red-500 font-semibold sm:text-4xl ">
//                       {product.name}
//                     </h1>
//                     {/* Product Description */}
//                     <p className="mt-3 text-gray-600 text-md leading-6 text-justify sm:text-left sm:mt-4">
//                       {product.description}
//                     </p>
//                     {/* Product Price */}
//                     <span className="text-xl text-green-500 font-semibold sm:text-2xl">
//                       Price ${product.price}
//                     </span>
//                   </div>
//                   {/* Quantity Input and Order Button */}
//                   <div className=" ">
//                     <div className="text-left flex flex-col gap-2 w-full">
//                       {/* Quantity Label */}
//                       {/* <label className="font-semibold">Quantity</label> */}
//                       {/* Quantity Input */}
//                       {/* <input
//                         className="border border-gray-300 text-sm font-semibold mb-1 max-w-full w-full outline-none rounded-md m-0 py-3 px-4 md:py-3 md:px-4 md:mb-0 focus:border-red-500"
//                         type="number"
//                         defaultValue="1"
//                         required
//                       /> */}
//                     </div>
//                     {/* Order Button */}
//                     <div className="w-full text-left my-4">
//                       <button
//                         className="flex justify-center items-center gap-2 w-full py-3 px-4 bg-red-500 text-white text-md font-bold border border-red-500 rounded-md ease-in-out duration-150 shadow-slate-600 hover:bg-white hover:text-red-500 lg:m-0 md:px-6"
//                         title="Confirm Order"
//                       >
                         
//                         <span onClick={handleAddToCartBtn}>Add to Cart</span>
//                         <HiOutlineArrowCircleRight />
//                       </button>
//                       <div className="dropdown dropdown-hover">
//                         <div tabIndex={0} role="button" className="btn m-1">
//                           Offer We Give You
//                         </div>
//                         <ul
//                           tabIndex={0}
//                           className="dropdown-content z-[1] menu p-2 shadow bg-base-100 rounded-box w-52 flex-row"
//                         >
                       
//                           <li>
//                             <input type="number"  value={product.offer} readOnly />
//                           </li>
//                             <button className="btn btn-primary rounded" onClick={()=>alert("Wait we will Update you ") }>Submit</button>
//                         </ul>
//                       </div>
//                     </div>
//                   </div>
//                 </div>
//               </div>
//             </div>
//           </div>
//         </div>
//       )}
//     </div>
//   );
// };

// export default SingleProduct;


// with offer


// import React, { useState, useEffect, useContext } from "react";
// import axios from "axios";
// import { useParams } from "react-router-dom";
// import { HiOutlineArrowCircleRight } from "react-icons/hi";
// import { groceryContext } from "../../Layout/Layout";
// import { handleSessionStorage } from "../../../utils/utils";

// const SingleProduct = () => {
//   const params = useParams();
//   const [product, setProduct] = useState(null);
//   const { cartItemsState } = useContext(groceryContext);
//   const [cartItems, setCartItems] = cartItemsState;
//   const [openAlert, setOpenAlert] = useState(false);

//   useEffect(() => {
//     getProduct(params?.slug);
//   }, [params?.slug]);

//   const getProduct = async (slug) => {
//     try {
//       // const { data } = await axios.get(`/api/v1/product/get-product/${slug}`);
//       const { data } = await axios.get( `http://localhost:3000/api/vi/product/get-product/${slug}`);
//       setProduct(data?.product);
//     } catch (error) {
//       console.error("Error fetching product:", error);
//     }
//   };

//   const handleAddToCartBtn = () => {
//     let targetedProduct = product;
//     let latestCartItems = cartItems;

//     const isTargetedProductAlreadyExist = cartItems.find(
//       (item) => item.id === product.id
//     );

//     if (isTargetedProductAlreadyExist) {
//       targetedProduct = {
//         ...isTargetedProductAlreadyExist,
//         quantity: isTargetedProductAlreadyExist.quantity + 1,
//         total: (
//           (isTargetedProductAlreadyExist.quantity + 1) *
//           isTargetedProductAlreadyExist.price
//         ).toFixed(2),
//       };
//       latestCartItems = cartItems.filter(
//         (item) => item.id !== targetedProduct.id
//       );
//     }

//     setCartItems([targetedProduct, ...latestCartItems]);
//     handleSessionStorage("set", "cartItems", [
//       targetedProduct,
//       ...latestCartItems,
//     ]);

//     setOpenAlert(!openAlert);
//   };

//   const handleApplyOffer = async () => {
//     try {
//       const { data } = await axios.post(`http://localhost:3000/api/vi/product/apply-offer/${product._id}`);
//       console.log("Offer applied successfully:", data);
//       // Assuming the offer has been applied successfully,
//       // you can update the product data or display a success message
//     } catch (error) {
//       console.error("Error applying offer:", error);
//       // Handle error while applying offer
//     }
//   };

//   const handleRemoveOffer = async () => {
//     try {
//       const { data } = await axios.post(`/api/v1/product/remove-offer/${product._id}`);
//       console.log("Offer removed successfully:", data);
//       // Assuming the offer has been removed successfully,
//       // you can update the product data or display a success message
//     } catch (error) {
//       console.error("Error removing offer:", error);
//       // Handle error while removing offer
//     }
//   };

//   return (
//     <div>
//       {product && (
//         <div className="p-3 max-w-7xl m-auto">
//           <div className="mt-6 sm:mt-10 p-12">
//             <div>
//               <h1 className="text-2xl font-medium font-poppins">
//                 Product Details
//               </h1>
//               <div className="grid gird-cols-1 md:grid-cols-3 sm:grid-cols-2 gap-6 h-max">
//                 <div className="overflow-hidden rounded-xl">
//                   <img
//                     // src={`/api/v1/product/product-photo/${product._id}`}
//                     src={`http://localhost:3000/api/vi/product/product-photo/${product._id}`}

//                     className="w-full"
//                     alt={product.name}
//                   />
//                 </div>
//                 <div className="flex flex-col justify-between">
//                   <div>
//                     <h1 className="text-3xl text-red-500 font-semibold sm:text-4xl">
//                       {product.name}
//                     </h1>
//                     <p className="mt-3 text-gray-600 text-md leading-6 text-justify sm:text-left sm:mt-4">
//                       {product.description}
//                     </p>
//                     <span className="text-xl text-green-500 font-semibold sm:text-2xl">
//                       Price ${product.price}
//                     </span>
//                   </div>
//                   <div className=" ">
//                     <div className="text-left flex flex-col gap-2 w-full">
//                     </div>
//                     <div className="w-full text-left my-4">
//                       <button
//                         className="flex justify-center items-center gap-2 w-full py-3 px-4 bg-red-500 text-white text-md font-bold border border-red-500 rounded-md ease-in-out duration-150 shadow-slate-600 hover:bg-white hover:text-red-500 lg:m-0 md:px-6"
//                         title="Add to Cart"
//                         onClick={handleAddToCartBtn}
//                       >
//                         <span>Add to Cart</span>
//                         <HiOutlineArrowCircleRight />
//                       </button>
//                       <div className="dropdown dropdown-hover">
//                         <div tabIndex={0} role="button" className="btn m-1">
//                           Offer
//                         </div>
//                         <ul
//                           tabIndex={0}
//                           className="dropdown-content z-[1] menu p-2 shadow bg-base-100 rounded-box w-52 flex-row"
//                         >
//                           {product.offerPrice && (
//                             <li>
//                               Offer Price: ${product.offerPrice}
//                             </li>
//                           )}
//                           {product.offerExpiryDate && (
//                             <li>
//                               Offer Expiry Date: {product.offerExpiryDate}
//                             </li>
//                           )}
//                           {product.offerPrice ? (
//                             <li>
//                               <button
//                                 className="btn btn-sm btn-primary mt-2"
//                                 onClick={handleRemoveOffer}
//                               >
//                                 Remove Offer
//                               </button>
//                             </li>
//                           ) : (
//                             <li>
//                               <button
//                                 className="btn btn-sm btn-primary mt-2"
//                                 onClick={handleApplyOffer}
//                               >
//                                 Apply Offer
//                               </button>
//                             </li>
//                           )}
//                         </ul>
//                       </div>
//                     </div>
//                   </div>
//                 </div>
//               </div>
//             </div>
//           </div>
//         </div>
//       )}
//     </div>
//   );
// };


// with apply correcct offer
// export default SingleProduct;
// import React, { useState, useEffect } from "react";
// import axios from "axios";
// import { useParams } from "react-router-dom";
// import { HiOutlineArrowCircleRight } from "react-icons/hi";

// const SingleProduct = () => {
//   const params = useParams();
//   const [product, setProduct] = useState(null);
//   const [offerApplied, setOfferApplied] = useState(false);

//   useEffect(() => {
//     getProduct(params?.slug);
//   }, [params?.slug]);

//   const getProduct = async (slug) => {
//     try {
//       console.log(slug)
//       // const { data } = await axios.get(`http://localhost:3000/api/v1/product/get-product/${slug}`);
//       const { data } = await axios.get(`http://localhost:3000/api/vi/product/get-product/${slug}`);
//       setProduct(data?.product);
//     } catch (error) {
//       console.error("Error fetching product:", error);
//     }
//   };

 
//   const handleApplyOffer = async () => {
//     try {
//       const { offerPrice, offerExpiryDate } = product;
//       const productId = product._id;
      
//       const { data } = await axios.put(`http://localhost:3000/api/vi/product/apply-offer/${productId}`, {
//         offerPrice,
//         offerExpiryDate,
//       });

//       console.log("Offer applied successfully:", data);

//       // Update the product price to the offer price
//       setProduct((prevProduct) => ({
//         ...prevProduct,
//         price: data.product.offerPrice, // Update the price with the offer price
//         offerPrice: data.product.offerPrice, // Update the offer price in the product state
//         offerExpiryDate: data.product.offerExpiryDate, // Update the offer expiry date in the product state
//       }));

//       setOfferApplied(true);
//     } catch (error) {
//       console.error("Error applying offer:", error);
//     }
//   };

//   const handleRemoveOffer = async () => {
//     try {
//       const { data } = await axios.put(`http://localhost:3000/api/vi/product/remove-offer/${product._id}`);
//       console.log("Offer removed successfully:", data);

//       // Reset the product price to the original price
//       setProduct((prevProduct) => ({
//         ...prevProduct,
//         price: data.product.originalPrice,
//       }));
//       setOfferApplied(false);
//     } catch (error) {
//       console.error("Error removing offer:", error);
//     }
//   };



//   return (
//     <div>
//       {product && (
//         <div className="p-3 max-w-7xl m-auto">
//           <div className="mt-6 sm:mt-10 p-12">
//             <div>
//               <h1 className="text-2xl font-medium font-poppins">Product Details</h1>
//               <div className="grid gird-cols-1 md:grid-cols-3 sm:grid-cols-2 gap-6 h-max">
//                 <div className="overflow-hidden rounded-xl">
//                   <img
//                   //  src={`http://localhost:3000/api/v1/product/product-photo/${product._id}`}
//                    src={`http://localhost:3000/api/vi/product/product-photo/${product._id}`}

//                    className="w-full" alt={product.name} />
//                 </div>
//                 <div className="flex flex-col justify-between">
//                   <div>
//                     <h1 className="text-3xl text-red-500 font-semibold sm:text-4xl">{product.name}</h1>
//                     <p className="mt-3 text-gray-600 text-md leading-6 text-justify sm:text-left sm:mt-4">{product.description}</p>
//                     <span className="text-xl text-green-500 font-semibold sm:text-2xl">Price ${product.price}</span>
//                   </div>
//                   <div className=" ">
//                     <div className="text-left flex flex-col gap-2 w-full"></div>
//                     <div className="w-full text-left my-4">
//                       <button className="flex justify-center items-center gap-2 w-full py-3 px-4 text-white text-md font-bold
//                        border border-green-500 rounded-md ease-in-out duration-150 shadow-slate-600 hover:bg-white  lg:m-0 md:px-6"
//                         title="Add to Cart"
//                         style={{background:"green"}}
//                         >
//                         <span style={{ border:"none"}}>Add to Cart</span>
//                         <HiOutlineArrowCircleRight />
//                       </button>
//                       <div className="dropdown dropdown-hover" style={  {
//                         display:"block",
//                        margin: "1rem 0rem 0rem 0rem"
//                        }}>
//                         <div tabIndex={0} role="button" className="btn m-1" style={{
//                               width: "100%",
//                               background: "#055205f0",
//                               color: "white",
//                               fontSize: "1.3rem"         
//                                                      }}>
//                           Offer
//                         </div>
//                         <ul tabIndex={0} className="dropdown-content z-[1] menu p-2 shadow bg-base-100 rounded-box w-52" 
//                         style={{
//                           width: "100%",
//                           background: "#185810",
//                           color: "white",
//                           display: "flex",
//                           flexDirection: "column",
//                         }}
//                         >
//                           {product.offerPrice ? (
//                             <>
//                               <li style={{fontSize:"1.1rem"}}>Offer Price: ${product.offerPrice}</li>
//                               <li style={{fontSize:"1.1rem"}}>Offer Expiry Date: {product.offerExpiryDate}</li>
//                             </>
//                           ) : (
//                             <li>No offer available</li>
//                           )}
//                           {offerApplied ? (
//                             <li>
//                               <button className="btn btn-sm btn-primary mt-2 "style={{color:"white"}} onClick={handleRemoveOffer}>
//                                 Remove Offer
//                               </button>
//                             </li>
//                           ) : (
//                             <li>
//                               <button className="btn btn-sm btn-primary mt-2" onClick={handleApplyOffer}>
//                                 Apply Offer
//                               </button>
//                             </li>
//                           )}
//                         </ul>
//                       </div>
//                     </div>
//                   </div>
//                 </div>
//               </div>
//             </div>
//           </div>
//         </div>
//       )}
//     </div>
//   );
// };

// export default SingleProduct;



import React, { useState, useEffect, useContext } from "react";
import axios from "axios";
import { useParams } from "react-router-dom";
import { HiOutlineArrowCircleRight } from "react-icons/hi";


import SuccessAlert from "../../SuccessAlert/SuccessAlert";
import { useNavigate } from "react-router-dom";
import { groceryContext } from "../../Layout/Layout";
import { handleSessionStorage } from "../../../utils/utils";

const SingleProduct = () => {
  const params = useParams();
  const [product, setProduct] = useState(null);

  const [offerApplied, setOfferApplied] = useState(false);


  useEffect(() => {
    getProduct(params?.slug);
  }, [params?.slug]);

  const getProduct = async (slug) => {
    try {
      const { data } = await axios.get(`http://localhost:3000/api/vi/product/get-product/${slug}`);
      setProduct(data?.product);
    } catch (error) {
      console.error("Error fetching product:", error);
    }
  };

  const handleApplyOffer = async () => {
    try {
      const { offerPrice, offerExpiryDate } = product;
      const productId = product._id;

      const { data } = await axios.put(`http://localhost:3000/api/vi/product/apply-offer/${productId}`, {
        offerPrice,
        offerExpiryDate,
      });

      console.log("Offer applied successfully:", data);

      setProduct((prevProduct) => ({
        ...prevProduct,
        price: data.product.offerPrice,
        offerPrice: data.product.offerPrice,
        offerExpiryDate: data.product.offerExpiryDate,
      }));

      setOfferApplied(true);
    } catch (error) {
      console.error("Error applying offer:", error);
    }
  };

  const handleRemoveOffer = async () => {
    try {
      const { data } = await axios.put(`http://localhost:3000/api/vi/product/remove-offer/${product._id}`);
      console.log("Offer removed successfully:", data);

      setProduct((prevProduct) => ({
        ...prevProduct,
        price: data.product.originalPrice,
      }));
      setOfferApplied(false);
    } catch (error) {
      console.error("Error removing offer:", error);
    }
  };

  const [openAlert, setOpenAlert] = useState(false)
  const { cartItemsState } = useContext(groceryContext);
  const [cartItems, setCartItems] = cartItemsState;

  //Handle Add To Cart
  const handleAddToCartBtn = () => {
      let targetedProduct = product;
      let latestCartItems = cartItems;
      console.log(product)
      console.log(product._id)
      const isTargetedProductAlreadyExist = cartItems.find(item => item.id === product._id)
      if (isTargetedProductAlreadyExist) {
          targetedProduct = {
              ...isTargetedProductAlreadyExist,
              quantity: isTargetedProductAlreadyExist.quantity + 1,
              total: ((isTargetedProductAlreadyExist.quantity + 1) * isTargetedProductAlreadyExist.price).toFixed(2)
          }
          latestCartItems = cartItems.filter(item => item.id !== targetedProduct.id)
      }
      setCartItems([
          targetedProduct,
          ...latestCartItems
      ])
      handleSessionStorage('set', 'cartItems', [
          targetedProduct,
          ...latestCartItems
      ])
       alert("Itme add to cart")
      setOpenAlert(!openAlert)
  }

  return (
    <div>
      {product && (
        <div className="p-3 max-w-7xl m-auto">
          <div className="mt-6 sm:mt-10 p-12">
            <div>
              <h1 className="text-2xl font-medium font-poppins">Product Details</h1>
              <div className="grid gird-cols-1 md:grid-cols-3 sm:grid-cols-2 gap-6 h-max">
                <div className="overflow-hidden rounded-xl">
                  <img src={`http://localhost:3000/api/vi/product/product-photo/${product._id}`} className="w-full" alt={product.name} />
                </div>
                <div className="flex flex-col justify-between">
                  <div>
                    <h1 className="text-3xl text-red-500 font-semibold sm:text-4xl">{product.name}</h1>
                    <p className="mt-3 text-gray-600 text-md leading-6 text-justify sm:text-left sm:mt-4">{product.description}</p>
                    <span className="text-xl text-green-500 font-semibold sm:text-2xl">Price ${product.price}</span>
                  </div>
                  <div className=" ">
                    <div className="text-left flex flex-col gap-2 w-full"></div>
                    <div className="w-full text-left my-4">
                      <button className="flex justify-center items-center gap-2 w-full py-3 px-4 text-white text-md font-bold border border-green-500 rounded-md ease-in-out duration-150 shadow-slate-600 hover:bg-white  lg:m-0 md:px-6" title="Add to Cart" onClick={handleAddToCartBtn} style={{ background: "green" }}>
                        <span style={{ border: "none" }}>Add to Cart</span>
                        <HiOutlineArrowCircleRight />
                      </button>
                      <div className="dropdown dropdown-hover" style={{ display: "block", margin: "1rem 0rem 0rem 0rem" }}>
                        <div tabIndex={0} role="button" className="btn m-1" style={{ width: "100%", background: "#055205f0", color: "white", fontSize: "1.3rem" }}>
                          Offer
                        </div>
                        <ul tabIndex={0} className="dropdown-content z-[1] menu p-2 shadow bg-base-100 rounded-box w-52" style={{ width: "100%", background: "#185810", color: "white", display: "flex", flexDirection: "column" }}>
                          {product.offerPrice ? (
                            <>
                              <li style={{ fontSize: "1.1rem" }}>Offer Price: ${product.offerPrice}</li>
                              <li style={{ fontSize: "1.1rem" }}>Offer Expiry Date: {product.offerExpiryDate}</li>
                            </>
                          ) : (
                            <li>No offer available</li>
                          )}
                          {offerApplied ? (
                            <li>
                              <button className="btn btn-sm btn-primary mt-2 " style={{ color: "white" }} onClick={handleRemoveOffer}>
                                Remove Offer
                              </button>
                            </li>
                          ) : (
                            <li>
                              <button className="btn btn-sm btn-primary mt-2" onClick={handleApplyOffer}>
                                Apply Offer
                              </button>
                            </li>
                          )}
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default SingleProduct;
