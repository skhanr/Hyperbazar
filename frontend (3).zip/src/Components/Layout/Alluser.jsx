import React from 'react'

const Alluser = () => {
  return (
    <div>Alluser</div>
  )
}

export default Alluser