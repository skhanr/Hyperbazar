// import React, { useState } from 'react'

// const Category = () => {
//    const[addCategory,setAddCategory] = useState({
//     category:"",
//     imageUrl:"",
//    })

//    const handleInput = (e)=>{
//      const name = e.target.name;
//      const value= e.target.value;
   
//      setAddCategory({
//       ...addCategory,
//       [name]:value
//     }) 
//     console.log(name)
//     console.log(value)
//    }
//    const handleAddCategory= async(e)=>{
//       e.preventDefault();
//       if(!addCategory.category || !addCategory.imageUrl)
//       {
//         alert("please fill fields")
//       }

//       try {
         
//         const response= await fetch(`http://localhost:3000/api/auth/categoryInventary`,{
//           method:"POST",
//           headers:{
//             "Content-Type":"application/json"
//           },
//           body:JSON.stringify(addCategory)
//         })
//      console.log(response);
//         if(response.ok)
//         {
//           alert("done");
//         }
//       } catch (error) {
        
//       }
//    }
//   return (
//     <div className="flex min-h-screen" >
//       {/* Form side */}
//       <div className="p-4 " style={{width:"100%"}}>
//         <div className="max-w-md mx-auto">
//           <h2 className="text-2xl font-bold mb-4">Add Inventory Category</h2>
//           {/* Category Name */}
//           <div className="form-control border-none">
//             <label className="label" htmlFor='categoryName'>
//               <span className="label-text">Category Name</span>
//             </label>
//             <input
//               type="text"
//               name='categoryName'
//               value={addCategory.category}
//               onChange={handleInput}
              
//               placeholder="Enter category name"
//               className="input input-bordered"
//             />
//           </div>
        
//           {/* Image URL */}
//           <div className="form-control border-none">
//             <label className="label" htmlFor='categoryImgUrl'>
//               <span className="label-text">Upload Image URL</span>
//             </label>
//             <input
//               type="text"
//               name='categoryImgUrl'
//               value={addCategory.imageUrl}
//               onChange={handleInput}
//               placeholder="Enter image URL"
//               className="input input-bordered"
//             />
//           </div>
//           {/* Add Button */}
//           <div className="form-control mt-4">
//             <button className="btn btn-primary" onClick={handleAddCategory}>
//               Add
//             </button>
//           </div>
//         </div>
//       </div>
  


//     </div>
//   );
// };

// export default Category;

// import React, { useState } from 'react';
// import AllCategories from '../../../AllCategories/AllCategories';

// const Category = () => {
//     const [addCategory, setAddCategory] = useState({
//         category: "",
//         imageUrl:"",
//     });

//     const handleInput = (e) => {
//         const { name, value } = e.target;
//         setAddCategory({
//             ...addCategory,
//             [name]: value
//         });
//     };

//     const handleAddCategory = async (e) => {
//         e.preventDefault();
//         if (!addCategory.category || !addCategory.imageUrl) {
//             alert("Please fill in all fields");
//             return;
//         }

//         try {
//             const response = await fetch(`http://localhost:3000/api/auth/categoryInventary`, {
//                 method: "POST",
//                 headers: {
//                     "Content-Type": "application/json"
//                 },
//                 body: JSON.stringify(addCategory)
//             });

//             if (response.ok) {
//                 alert("Category added successfully");
//                 setAddCategory({
//                     category: "",
//                     imageUrl: ""
//                 });
//             }
//         } catch (error) {
//             console.error('Error adding category:', error);
//         }
//     };

//     return (
//         <div className="flex min-h-screen m-12">
//             {/* Form side */}
//             <div className="p-4 " style={{ width: "100%" }}>
//                 <div className="max-w-md mx-auto">
//                     <h2 className="text-2xl font-bold mb-4">Add Inventory Category</h2>
//                     {/* Category Name */}
//                     <div className="form-control border-none">
//                         <label className="label" htmlFor='categoryName'>
//                             <span className="label-text">Category Name</span>
//                         </label>
//                         <input
//                             type="text"
//                             name='category'
//                             value={addCategory.category}
//                             onChange={handleInput}
//                             placeholder="Enter category name"
//                             className="input input-bordered"
//                         />
//                     </div>
//                     {/* Image URL */}
//                     <div className="form-control border-none">
//                         <label className="label" htmlFor='categoryImgUrl'>
//                             <span className="label-text">Upload Image URL</span>
//                         </label>
//                         <input
//                             type="text"
//                             name='imageUrl'
//                             value={addCategory.imageUrl}
//                             onChange={handleInput}
//                             placeholder="Enter image URL"
//                             className="input input-bordered"
//                         />
//                     </div>
//                     {/* Add Button */}
//                     <div className="form-control mt-4">
//                         <button className="btn btn-primary" onClick={handleAddCategory}>
//                             Add
//                         </button>
//                     </div>
//                 </div>

//               <div className='max-w-md mt-10 '>
//               {/* <h2 className="text-2xl font-bold mb-4 ">ALL Category  */}
//               {/* </h2> */}
//                <AllCategories />
//               </div>
//             </div>
//         </div>
//     );
// };

// export default Category;



/// 111111

import React, { useEffect, useState } from "react";
import toast from "react-hot-toast";
import axios from "axios";
import { Modal } from "antd";
import CategoryForm from "../../../Form/CategoryForm";

const Category = () => {
  const [categories, setCategories] = useState([]);
  const [name, setName] = useState("");
  const [visible, setVisible] = useState(false);
  const [selected, setSelected] = useState(null);
  const [updatedName, setUpdatedName] = useState("");
  //handle Form
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const { data } = await axios.post("http://localhost:3000/api/vi/category/create-category", {
        name,
      });
      if (data?.success) {
        toast.success(`${name} is created`);
        alert("created succesfully")
        getAllCategory();
      } else {
        toast.error(data.message);
      }
    } catch (error) {
      console.log(error);
      toast.error("somthing went wrong in input form");
    }
  };

  //get all cat
  const getAllCategory = async () => {
    try {
      const { data } = await axios.get("http://localhost:3000/api/vi/category/get-category");
      if (data.success) {
        setCategories(data.category);
      }
    } catch (error) {
      console.log(error);
      toast.error("Something went wrong in getting category");
    }
  };

  useEffect(() => {
    getAllCategory();
  }, []);

  //update category
  const handleUpdate = async (e) => {
    e.preventDefault();
    try {
      const { data } = await axios.put(`http://localhost:3000/api/vi/category/update-category/${selected._id}`,{ name: updatedName });
      if (data.success) {
        toast.success(`${updatedName} is updated`);
        setSelected(null);
        setUpdatedName("");
        setVisible(false);
        getAllCategory();
      } else {
        toast.error(data.message);
      }
    } catch (error) {
      toast.error("Somtihing went wrong");
    }
  };
  //delete category
  const handleDelete = async(e) => {

    try {
      const id = selected._id;
      // console.log(id);
      const { data } = await axios.delete(`http://localhost:3000/api/vi/category/delete-category/${id}`);
      
        //  const { data } = await axios.delete(`http://localhost:3000/api/v1/category/delete-category/${id}`);
      if (data.success) {
        toast.success(`category is deleted`);
        alert("deleted")
        getAllCategory();
      } else {
        toast.error(data.message);
        alert("error occured")
      }
    } catch (error) {
      toast.error("Somtihing went wrong");
     alert("interval server error")
    }

  };
  return (

    <main>
    <div className="row">
        <h1>Category Managment</h1>
        <CategoryForm
                 handleSubmit={handleSubmit}
                 value={name}
                 setValue={setName}
               />
    </div>
       <div className="w-75">
       <table className="table">
         <thead>
           <tr>
             <th scope="col">Name</th>
             <th scope="col">Actions</th>
           </tr>
         </thead>
         <tbody>
           {categories?.map((c) => (
             <>
               <tr>
                 <td key={c._id}>{c.name}</td>
                 <td>
                   <button
                     className="btn btn-primary ms-2"
                     onClick={() => {
                      handleUpdate(c._id);
                      setVisible(true);
                       setUpdatedName(c.name);
                       setSelected(c);
                     }}
                   >
                     Edit
                   </button>
                   <button
                     className="btn btn-danger ms-2"
                     onClick={() => {
                       handleDelete(c._id);
                       setSelected(c);
                     }}
                   >
                     Delete
                   </button>
                 </td>
               </tr>
             </>
           ))}
         </tbody>
       </table>
     </div>
     <Modal
              onCancel={() => setVisible(false)}
              footer={null}
              visible={visible}
            >
              <CategoryForm
                value={updatedName}
                setValue={setUpdatedName}
                handleSubmit={handleUpdate}
              />
            </Modal>
  </main>
  );
};

export default Category;



// import React, { useState } from 'react';
// import AllCategories from '../../../AllCategories/AllCategories';
// import toast from "react-hot-toast";
// import axios from "axios";
// const Category = () => {
     

//     return (
//         <div className="flex min-h-screen m-12">
//             {/* Form side */}
//             <div className="p-4 " style={{ width: "100%" }}>
//                 <div className="max-w-md mx-auto">
//                     <h2 className="text-2xl font-bold mb-4">Add Inventory Category</h2>
//                     {/* Category Name */}
//                     <div className="form-control border-none">
//                         <label className="label" htmlFor='categoryName'>
//                             <span className="label-text">Category Name</span>
//                         </label>
//                         <input
//                             type="text"
//                             name='category'
//                             value={addCategory.category}
//                             onChange={handleInput}
//                             placeholder="Enter category name"
//                             className="input input-bordered"
//                         />
//                     </div>
//                     {/* Image URL */}
//                     {/* <div className="form-control border-none">
//                         <label className="label" htmlFor='categoryImgUrl'>
//                             <span className="label-text">Upload Image URL</span>
//                         </label>
//                         <input
//                             type="text"
//                             name='imageUrl'
//                             value={addCategory.imageUrl}
//                             onChange={handleInput}
//                             placeholder="Enter image URL"
//                             className="input input-bordered"
//                         />
//                     </div> */}
//                     {/* Add Button */}
//                     <div className="form-control mt-4">
//                         <button className="btn btn-primary" onClick={handleAddCategory}>
//                             Add
//                         </button>
//                     </div>
//                 </div>

//               <div className='max-w-md mt-10 '>
//               {/* <h2 className="text-2xl font-bold mb-4 ">ALL Category  */}
//               {/* </h2> */}
//                <AllCategories />
//               </div>
//             </div>
//         </div>
//     );
// };

// export default Category;